addpath('../external/');
addpath('../external/export_fig');

%% Example to Visualize and Save Result (with Ground Truth)
% load('../data/cluster/data_TwoDiamonds.mat');
% visualize('./results/result_TwoDiamonds.png', D, L)

%% Your Code